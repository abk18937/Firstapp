package koffi.simplifiedcodingalpha.com.patrick.model;

public class RelevanteFehlebilderModel {
    public String getItemName() {
        return itemName;
    }

    public void setItemName(String itemName) {
        this.itemName = itemName;
    }

    public RelevanteFehlebilderModel(String itemName) {
        this.itemName = itemName;
    }
    public RelevanteFehlebilderModel() {

    }
    public String itemName;




}
